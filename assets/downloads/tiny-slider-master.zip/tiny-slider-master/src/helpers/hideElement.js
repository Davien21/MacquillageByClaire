export function hideElement(el, forceHide) {
  if (el.style.display !== 'none') { el.style.display = 'none'; }
}